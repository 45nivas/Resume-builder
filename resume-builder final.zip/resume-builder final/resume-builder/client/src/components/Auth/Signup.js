import React from "react";

const Signup = () => {
  return (
    <div>
      <h2>Sign Up</h2>
      <form>
        {/* Add your sign-up form here */}
      </form>
    </div>
  );
};

export default Signup;